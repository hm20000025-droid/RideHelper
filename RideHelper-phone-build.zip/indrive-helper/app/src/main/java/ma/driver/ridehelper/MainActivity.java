package ma.driver.ridehelper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 501;
    private MediaProjectionManager projectionManager;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,40,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this); title.setText("Ride Helper — مساعد رحلات inDrive"); title.setTextSize(22); title.setPadding(0,0,0,18); root.addView(title);
        TextView info = new TextView(this); info.setText("كيحلل النص الظاهر فالشاشة ويعرض ضوء عائم: أخضر عند 3 دراهم/كم أو أكثر، وأحمر تحت 3. خاصك توافق على التقاط الشاشة والسماح بالظهور فوق التطبيقات. هادي نسخة تجريبية وقد تخطئ فقراءة الأرقام."); info.setTextSize(16); info.setPadding(0,0,0,24); root.addView(info);
        Button start = new Button(this); start.setText("تشغيل الضوء العائم"); root.addView(start);
        Button stop = new Button(this); stop.setText("إيقاف التحليل"); root.addView(stop);
        TextView formula = new TextView(this); formula.setText("الحساب: ثمن الرحلة ÷ (المسافة إلى الزبون + مسافة الرحلة)\nالهدف: 3 دراهم/كم"); formula.setPadding(0,24,0,0); root.addView(formula);
        setContentView(root);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); return; }
            startActivityForResult(projectionManager.createScreenCaptureIntent(), CAPTURE_REQUEST);
        });
        stop.setOnClickListener(v -> { stopService(new Intent(this, ScreenScanService.class)); });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == CAPTURE_REQUEST && resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, ScreenScanService.class); service.putExtra("resultCode", resultCode); service.putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            moveTaskToBack(true);
        }
    }
}
