package ma.driver.ridehelper;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.view.*;
import android.widget.TextView;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.regex.*;

public class ScreenScanService extends Service {
    private WindowManager wm; private View bubble; private TextView lamp; private MediaProjection projection; private VirtualDisplay display; private ImageReader reader; private Handler handler; private TextRecognizer recognizer;
    private int screenW, screenH, density; private boolean processing=false; private long lastScan=0;
    @Override public void onCreate() { super.onCreate(); handler = new Handler(Looper.getMainLooper()); recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS); createNotification(); createBubble(); }
    private void createNotification() {
        String channel="ridehelper_scan"; if (Build.VERSION.SDK_INT>=26) { NotificationChannel c=new NotificationChannel(channel,"Ride Helper screen analysis",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); }
        Notification n=new Notification.Builder(this,channel).setContentTitle("Ride Helper يعمل").setContentText("تحليل الشاشة محلياً").setSmallIcon(android.R.drawable.ic_menu_compass).build(); startForeground(7,n);
    }
    private void createBubble() {
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); lamp=new TextView(this); lamp.setText("● ؟"); lamp.setTextSize(23); lamp.setTextColor(Color.WHITE); lamp.setGravity(Gravity.CENTER); lamp.setPadding(14,8,14,8); lamp.setBackground(round(Color.DKGRAY)); lamp.setOnTouchListener(new View.OnTouchListener(){float x,y; int sx,sy; public boolean onTouch(View v, android.view.MotionEvent e){ if(e.getAction()==0){x=e.getRawX();y=e.getRawY(); WindowManager.LayoutParams p=(WindowManager.LayoutParams)v.getLayoutParams();sx=p.x;sy=p.y;return true;} if(e.getAction()==2){WindowManager.LayoutParams p=(WindowManager.LayoutParams)v.getLayoutParams();p.x=sx+(int)(e.getRawX()-x);p.y=sy+(int)(e.getRawY()-y);wm.updateViewLayout(v,p);return true;}return true;}});
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.RIGHT; p.x=18;p.y=180; wm.addView(lamp,p); bubble=lamp;
    }
    private android.graphics.drawable.GradientDrawable round(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(60);return d;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){ if(intent==null)return START_NOT_STICKY; int rc=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED); Intent data=intent.getParcelableExtra("data"); if(data!=null){ MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); projection=m.getMediaProjection(rc,data); startCapture(); } return START_STICKY; }
    private void startCapture(){
        android.util.DisplayMetrics dm=new android.util.DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm); screenW=dm.widthPixels;screenH=dm.heightPixels;density=dm.densityDpi;
        reader=ImageReader.newInstance(screenW,screenH,PixelFormat.RGBA_8888,2);
        projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
        display=projection.createVirtualDisplay("RideHelperCapture",screenW,screenH,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireLatestImage();if(im==null||processing||System.currentTimeMillis()-lastScan<650)return;processing=true;lastScan=System.currentTimeMillis(); Bitmap b=imageBitmap(im); if(b!=null) scan(b);}catch(Exception e){processing=false;}finally{if(im!=null)im.close();}},handler);
    }
    private Bitmap imageBitmap(Image image){ Image.Plane plane=image.getPlanes()[0]; ByteBuffer buf=plane.getBuffer(); int pixelStride=plane.getPixelStride(),rowStride=plane.getRowStride(); int rowPadding=rowStride-pixelStride*screenW; Bitmap padded=Bitmap.createBitmap(screenW+rowPadding/pixelStride,screenH,Bitmap.Config.ARGB_8888); padded.copyPixelsFromBuffer(buf); Bitmap out=Bitmap.createBitmap(padded,0,0,screenW,screenH); padded.recycle(); return out; }
    private void scan(Bitmap bitmap){ recognizer.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener(result->{String t=result.getText(); evaluate(t);}).addOnFailureListener(e->{setLamp(Color.DKGRAY,"؟");}).addOnCompleteListener(task->{bitmap.recycle();processing=false;}); }
    private void evaluate(String text){
        String normalized=text.toLowerCase().replace(',', '.').replace('٫','.');
        // Accept common Moroccan fare labels, including Arabic OCR variants.
        Double price=null;
        Matcher pm=Pattern.compile("(?i)(\\d+(?:\\.\\d{1,2})?)\\s*(?:mad|dhs?|dirhams?|د\\s*رهم|درهم|د\\.?م\\.?|دج\\.?)").matcher(normalized);
        if(pm.find()) try { price=Double.parseDouble(pm.group(1)); } catch(Exception ignored) {}
        java.util.ArrayList<Double> kms=new java.util.ArrayList<>();
        Matcher km=Pattern.compile("(?i)(\\d+(?:\\.\\d{1,2})?)\\s*(?:km|kms|kilomet(?:er|re)s?|كم|كلم)").matcher(normalized);
        while(km.find()) {
            try {
                double v=Double.parseDouble(km.group(1));
                if(v>0 && v<1000) {
                    boolean duplicate=false;
                    // inDrive repeats the pickup distance on the map and in the fare card.
                    for(Double existing:kms) if(Math.abs(existing-v)<0.05) { duplicate=true; break; }
                    if(!duplicate) kms.add(v);
                }
            } catch(Exception ignored) {}
        }
        if(price==null || kms.size()<2){setLamp(Color.DKGRAY,"● ؟");return;}
        double total=0; for(Double v:kms) total+=v;
        double rate=price/total;
        if(rate>=3.0) setLamp(Color.rgb(22,163,74),String.format(java.util.Locale.US,"● %.2f",rate)); else setLamp(Color.rgb(217,45,32),String.format(java.util.Locale.US,"● %.2f",rate));
    }
    private void setLamp(int color,String text){handler.post(()->{if(lamp!=null){lamp.setText(text);lamp.setBackground(round(color));}});}
    @Override public void onDestroy(){super.onDestroy();try{if(reader!=null)reader.close();if(display!=null)display.release();if(projection!=null)projection.stop();if(wm!=null&&bubble!=null)wm.removeView(bubble);if(recognizer!=null)recognizer.close();}catch(Exception ignored){}}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
