# Ride Helper — prototype Android app

This is a lightweight proof-of-concept Android project for an inDrive driver. It requests Android screen-capture permission, reads visible text locally using ML Kit OCR, and shows a movable floating indicator. It tries to find a fare and two distances and computes fare / (distance to pickup + trip distance). Green = >= 3 MAD/km; red = below 3; grey question mark = information not confidently detected.

## Important limitations
- This is source code, not a compiled APK. Build with Android Studio (JDK 17, Android SDK 35, Gradle plugin 8.7.3); Gradle downloads ML Kit and Android build dependencies.
- OCR parsing is heuristic and will need tuning against screenshots from the exact inDrive offer screen and language. It may misread numbers or select the wrong distances. Always verify before accepting a trip.
- It does not click Accept/Reject, bypass inDrive protections, or send screen contents to a server. OCR is processed on-device.
- Android may require allowing “Display over other apps” and granting screen capture each time. Android versions may require notification permission.
- Use only while parked safely; do not interact with the phone while driving.

## Calibration note from the supplied Tangier screenshot
The offer shows 16 MAD, 6.5 km to pickup, and 2.6 km for the passenger trip: total 9.1 km and about 1.76 MAD/km, so the expected result is red. The parser now deduplicates repeated identical distance labels (the 6.5 km pickup distance appears both on the map and in the fare card) and accepts more fare-label variants. This is still heuristic: ML Kit's bundled Latin recognizer does not reliably recognize Arabic labels, so this screenshot must be tested on-device before trusting the floating indicator.

## Build APK using only your phone (cloud build)
This project includes a GitHub Actions workflow in `.github/workflows/android.yml`. It builds a debug APK in the cloud, so a PC is not required, but a GitHub account and browser are needed.

1. Create a new repository on GitHub (in the browser, choose **Add file → Upload files**).
2. Upload the contents of this project folder, including the hidden `.github/workflows/android.yml` file. If your mobile browser makes hidden folders difficult to upload, use GitHub's web editor to create `.github/workflows/android.yml` and paste the workflow from this project.
3. Open the repository's **Actions** tab, select **Build RideHelper APK**, and tap **Run workflow** (or push to `main` to trigger it).
4. When the run finishes successfully, open that run and download the artifact named `RideHelper-debug-apk`. Unzip it on your phone to get `app-debug.apk`.
5. Install the APK, open RideHelper, grant screen-capture permission and “Display over other apps” permission, then test while parked.

A cloud build only compiles the prototype; it does not prove OCR accuracy. Confirm that the screenshot showing 16 MAD, 6.5 km and 2.6 km produces red (1.76 MAD/km) before relying on it.
